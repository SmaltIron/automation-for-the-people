automation-for-the-people CHANGELOG
===================================

This file is used to list changes made in each version of the automation-for-the-people cookbook.

0.1.0
-----
- [your_name] - Initial release of automation-for-the-people

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
