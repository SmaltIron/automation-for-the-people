Requires Chef 0.10.0+.

This directory is for Ruby DSL and JSON files for environments. For more information see the Chef wiki page:

http://docs.chef.io/environments.html
